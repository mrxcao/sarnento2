<template>
  <div id="app">
    <Loading />
    <v-app>
      <Snackbar />
      <Aside v-if="mostrarAside" />
      <Barra
        v-if="!esconderBarra"
        :search="search"
        @update-search="updateSearch"
      />
      <v-main>
        <v-expand-transition>
          <router-view></router-view>
        </v-expand-transition>
      </v-main>
      <!--
      <Confirm ref="confirm"></Confirm>
      -->
    </v-app>
  </div>
</template>

<!--
<template>
   <div class="app">
    <div class="list-container">
      <ul class="horizontal-list">
        <li><router-link :to="{name:'home'}" >Home</router-link></li>
        <li><router-link :to="{name:'comofunciona'}">Como funciona?</router-link></li>
        <li><router-link :to="{name:'comandos'}">Comandos</router-link></li>
        <li><router-link :to="{name:'sourcecode'}">Github </router-link></li>
        <li><router-link :to="{name:'dashboard'}">Dashboard</router-link> </li>
      </ul>

      <div class="right-div">
          <template v-if="auth.authOk">
                <img class="avatar"  :src="auth.avatar">
                Olá {{ auth.fullName }}
                <button @click="logout" class="button-link">
                  Logout
                </button>
          </template>
              <template v-else>
                Olá visitante

                <router-link :to="{name:'login'}" class="button-link">login </router-link>

          </template>

      </div>

    </div>

    <div>
      <asideMenu />
    </div>

    <div class="router-content">
          <router-view></router-view>
    </div>

    <div class="footer" >
        <span :title = "status.apiInfo" >Status:</span>
        <template v-if="status.statusApi">
          <span  class="bolinha-verde"></span>
        </template>
        <template v-else>
          <span  class="bolinha-vermelha"></span>
        </template>
    </div>

  </div>
</template>
-->

<script setup>
import { onMounted } from 'vue';

import Aside from './components/layout/AsideMenu.vue';
import Barra from './components/layout/BarraMenu.vue';
// import Confirm from '@/components/Utils/Confirm.vue';
// import Loading from '@/components/Utils/Loading.vue';
// import Snackbar from '@/components/Utils/Snackbar.vue';

import { useAuth } from './store/auth';
import { useStatus } from './store/status';
// import { asideMenu } from './components/asideMenu.vue';

const auth = useAuth();
const status = useStatus();

onMounted(() => {
//  console.log('2-1- onMounted el.value', status.statusApi);
  status.checkStatus();
});

function logout() {
  auth.clear();
}

</script>

<style lang="scss" scoped>
</style>
