export default class TextoUtils {
  /**
   * Método para converter String para Number.
   * @param {*} texto em formato String
   * @returns número convertido
   */
  static converterStringParaNumber(texto) {
    if (texto && texto.length > 0) {
      return Number.parseInt(this.formatarTextoApenasNumeros(texto));
    }
    return texto;
  }

  static getQtdeValoresSeparadosPorVirgula(texto) {
    return texto.split(',').length;
  }

  static formatarNumeroCasasDecimais(valor, qtdeCasasDecimais) {
    if (isNaN(valor)) { throw Error('O valor informado não é numérico'); }

    return valor.toFixed(qtdeCasasDecimais).toString()
      .replace('.', ',');
  }

  static formatarTextoApenasNumeros(texto) {
    if (texto && texto.length > 0) {
      return texto.replace(/\D/g, '');
    }
    return texto;
  }

  static toUpperCase(texto) {
    if (texto && texto.length > 0) {
      return texto.toUpperCase();
    }
    return texto;
  }
}
