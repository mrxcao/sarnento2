<template>
    <div class="home">
       comandos
    </div>
  </template>
  
  <script>

  </script>
  