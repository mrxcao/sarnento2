<template>
    <div class="home">
       como funciona
    </div>
  </template>
  
  <script>

  </script>
  