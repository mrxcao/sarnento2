<template>
  <v-navigation-drawer width="110px" permanent app class="aside-b">
    <div class="d-flex justify-center">
      <img :src="logo" width="70" class="mb-6 mt-6" />
    </div>
    <v-list class="pa-0">
      <template v-for="item in items">
        <v-list-item
          v-if="item.shouldRender"
          :key="item.id"
          :to="item.to"
          @click="tab = item.id"
          class="align-center justify-center"
          :class="{
            'primary--text': item.id === tab,
            'white--text': item.id !== tab,
          }"
        >
          <v-tooltip right max-width="250" open-delay="20">
            <template v-slot:activator="{ on, attrs }">
              <v-list-item-icon class="icon-text" v-bind="attrs" v-on="on">
                <v-icon v-text="item.icon"></v-icon>
                <span class="titulo" :color="corIcone(item.id)">
                  {{ item.text }}
                </span>
              </v-list-item-icon>
            </template>
            <span> {{ item.tooltip }} </span>
          </v-tooltip>
        </v-list-item>
      </template>
    </v-list>
    <div class="d-flex justify-center versao">
      Versão:<br />{{ $store.getters.getVersaoAplicacao }}
    </div>
  </v-navigation-drawer>
</template>

<script>
import { mapGetters } from 'vuex';
import logo from '@/assets/img/logo_atende3.png';

export default {
  data: () => ({
    items: [],
    logo,
    mini: true,
    tab: null,
  }),
  computed: {
    ...mapGetters('authentication', [
      'usuario',
      'isUsuarioCelulaInovacao',
      'isUsuarioFuncaoGerencial',
      'isUsuarioFuncaoTecnicaMasterOuConsultor',
    ]),
  },
  methods: {
    corIcone(index) {
      return index === this.tab ? 'primary' : 'white';
    },
    podeVisualizar(id) {
      let condicao = false;

      if ([6, 8].includes(id)) {
        condicao = this.isUsuarioCelulaInovacao;
      } else if ([2, 7].includes(id)) {
        condicao = this.isUsuarioFuncaoGerencial
          || this.isUsuarioFuncaoTecnicaMasterOuConsultor
          || this.isUsuarioCelulaInovacao;
      }

      return condicao;
    },
  },
  watch: {
    $route(to) {
      // Foi necessário adicionar o watch pós ao navegar via breadcrumb
      // o vuetify não estava marcando como ativo a rota home
      if (!to || to.name == 'Home') this.tab = 1;
    },
    usuario: {
      handler() {
        this.items = [
          {
            id: 1,
            text: 'Home',
            tooltip: 'Pagina Inicial',
            icon: 'fas fa-home',
            to: '/home',
            shouldRender: true,
          },
          {
            id: 5,
            text: 'Pesquisa',
            tooltip: 'Pesquisa completa e avançada de Atendes',
            icon: 'fas fa-search',
            to: '/pesquisar',
            shouldRender: true,
          },
          {
            id: 2,
            text: 'Relatórios',
            tooltip: 'Relatórios diversos para controle e gestão',
            icon: 'fas fa-list',
            to: '/relatorios/resumoPorDia',
            shouldRender: this.podeVisualizar(2),
          },
          {
            id: 3,
            text: 'Configurações',
            tooltip:
              'Altere, Inclua e Personalize seus dados de acordo com sua necessidade.',
            icon: 'fas fa-cog',
            to: '/configuracoes/notificacoes',
            shouldRender: true,
          },
          {
            id: 9,
            text: 'Administrador',
            tooltip:
              'Painel Administrador para diversos acessos a configurações da ferramenta Atende',
            icon: 'fa-solid fa-toolbox',
            to: '/admin/categorias',
            shouldRender: this.podeVisualizar(8),
          },
          {
            id: 4,
            text: 'Ajuda',
            tooltip:
              'Tire todas suas dúvidas nesta seção, com FAQ, Cartilhas e demais itens disponíveis',
            icon: 'fas fa-question-circle',
            to: '/ajuda',
            shouldRender: true,
          },
        ];
      },
      immediate: true,
    },
  },
};
</script>

<style>
.v-navigation-drawer__content {
  display: contents;
}
.theme--dark .v-list-item--active::before {
  opacity: 0 !important;
}
.theme--light.aside-b {
  background-color: #48586c !important;
}
.theme--dark .aside-b {
  background-color: #393939 !important;
}
</style>

<style scoped>
.theme--light.v-list-item:not(.v-list-item--active):not(.v-list-item--disabled) {
  color: #fff !important;
}
.theme--light.v-icon {
  color: none;
}
.theme--light.v-list-item--active::before {
  opacity: 0 !important;
}
.v-list {
  background-color: transparent !important;
}
img {
  max-width: 70%;
  align-self: center;
}
.titulo {
  margin-top: 4px;
  font-size: 12px;
}
.icon-text {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: 13px 13px 13px 13px !important;
}
.icon-text i {
  font-size: 18px;
  color: #fff;
}
.versao {
  font-size: 11px;
  color: #fff;
  margin-top: auto !important;
  margin-bottom: 20px;
  text-align: center;
}
</style>
