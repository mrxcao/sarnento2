<template>
    <v-app-bar
      app
      class="elevation-3"
      v-scroll="onScroll"
      height="58"
      style="z-index: 10"
    >

      <v-spacer></v-spacer>
      <MenuBarra
        class="menu"
        :mostraBotoes="mostrarMenu"
        :search="search"
        @update-search="updateSearch"
      ></MenuBarra>

      <Usuario />
    </v-app-bar>
  </template>

<script>
export default {
  props: {
    search: String,
  },
  components: {
    Usuario: () => import('./Usuario.vue'),
    MenuBarra: () => import('./MenuBarra.vue'),

  },
  data() {
    return {
      scrollTop: 0,
    };
  },
  methods: {
    updateSearch(v) {
      this.$emit('update-search', v);
    },
    onScroll() {
      this.scrollTop = window.scrollTop || document.documentElement.scrollTop;
    },
  },
  computed: {
    mostrarMenu() {
      const condicao = (this.scrollTop > 333 && this.$route.name === 'Home')
          || this.$route.name !== 'Home';

      return condicao;
    },

  },
};
</script>

  <style>
  .theme--dark.v-app-bar.v-toolbar.v-sheet {
    box-shadow: none !important;
  }
  .theme--light.v-app-bar.v-toolbar.v-sheet {
    background-color: white !important;
  }
  </style>
  <style scoped>
  .hide-menu {
    transform: scaleX(0);
  }
  .menu {
    transform-origin: right;
    transition: transform 0.2s ease;
  }
  </style>

  <style scoped>
  .grau-sigilo-barra {
    font-size: 13px;
  }
  </style>
