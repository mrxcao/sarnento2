<template>
  <v-menu offset-y open-on-hover>
    <template #activator="{ on, attrs }">
      <v-btn text v-on="on" v-bind="attrs" large>
        <v-avatar size="35" class="mr-2">
          <v-img :src="avatarSrc" @error="onImgError()"></v-img>
        </v-avatar>
        <span class="pl-1 text-capitalize name-bt">Olá {{ firstName }}</span>
      </v-btn>
    </template>
    <v-list max-width="300" class="pt-0">
      <v-list-item two-line class="user-desc py-4">
        <v-list-item-content class="ml-6">
          <v-list-item-title class="white--text pb-1">
            <b>{{ name }}</b>
          </v-list-item-title>
          <v-list-item-subtitle class="white--text pb-1">
            {{ functionName }}
          </v-list-item-subtitle>
          <v-list-item-subtitle class="white--text"
            >{{ matricula }} - {{ unidade }} {{ cgcUnidade }}
          </v-list-item-subtitle>
        </v-list-item-content>
      </v-list-item>
      <v-divider></v-divider>
      <v-list-item v-if="hasLotacaoFisica">
        <v-list-item-content class="pb-0 mb-0">
          <v-switch
            color="success"
            class="switchUnidade pb-0 mb-0"
            :label="getLabelLotacaoFisica"
            v-model="lotacaoFisica"
            @change="alternarTipoLotacao()"
          ></v-switch>
        </v-list-item-content>
      </v-list-item>
      <v-list-item>
        <v-list-item-content class="py-0 mt-0">
          <v-switch
            v-model="temaEscuro"
            class="pt-6 mt-0"
            color="success"
            :label="label_tema_escuro"
            @change="altera_tema"
          ></v-switch>
        </v-list-item-content>
      </v-list-item>
      <v-list-item to="/configuracoes/notificacoes">
        <v-list-item-icon>
          <v-icon>fas fa-cog</v-icon>
        </v-list-item-icon>
        <v-list-item-content>Configurações</v-list-item-content>
      </v-list-item>
      <v-divider></v-divider>
      <v-list-item @click="doLogout">
        <v-list-item-icon>
          <v-icon>fas fa-sign-out-alt</v-icon>
        </v-list-item-icon>
        <v-list-item-content>Sair</v-list-item-content>
      </v-list-item>
    </v-list>
  </v-menu>
</template>

<script>
import img from "@/assets/img/0.png";
import { mapActions, mapGetters } from "vuex";
import Vue from "vue";

export default {
  data() {
    return {
      img,
      timer: null,
      lotacaoFisica: false,
      temaEscuro: false,
      imgError: false,
    };
  },
  computed: {
    ...mapGetters("authentication", [
      "usuario",
      "dark",
      "hasLotacaoFisica",
      "isLotacaoFisica",
    ]),
    name() {
      return this.usuario ? this.usuario.NOME : "";
    },
    avatarSrc() {
      const matr = (this.usuario || {}).MATRICULASTR;
      return matr
        ? this.imgError
          ? img
          : "http://tedx.caixa/lib/asp/foto.asp?Matricula=" + matr
        : null;
    },
    firstName() {
      if (!this.name.length) return "";
      const firstName = this.name.split(" ")[0].toLowerCase();

      return firstName;
    },
    functionName() {
      return this.usuario ? this.usuario.NOME_FUNCAO : "";
    },
    getLabelLotacaoFisica() {
      return `${this.lotacaoFisica ? "Desativar" : "Ativar"} Lotação Física`;
    },
    unidade() {
      return this.usuario ? this.usuario.SIGLA_UNIDADE : "";
    },
    matricula() {
      return this.usuario ? this.usuario.MATRICULASTR : "";
    },
    cgcUnidade() {
      return this.usuario ? this.usuario.UNIDADE : "";
    },
    label_tema_escuro() {
      return (!this.dark ? "Ativar" : "Desativar") + " Modo Escuro";
    },
  },
  methods: {
    onImgError() {
      this.imgError = true;
    },
    ...mapActions("authentication", [
      "logout",
      "loginUnidadeFisica",
      "logoutUnidadeFisica",
      "setDarkTheme",
    ]),
    doLogout() {
      /** throttle -Evita varias requisições ao banco-*/
      this.timer && clearTimeout(this.timer);

      this.timer = setTimeout(() => {
        this.logout();
      }, 100);
    },
    async alternarTipoLotacao() {
      if (this.isLotacaoFisica === false) {
        this.loginUnidadeFisica();
        return;
      }
      if (this.isLotacaoFisica === true) {
        this.logoutUnidadeFisica();
        return;
      }

      this.$nextTick(() => {
        Vue.set(this, "lotacaoFisica", this.isLotacaoFisica);
        throw new Error("Erro ao tentar alternar o tipo de lotação");
      });
    },
    altera_tema() {
      this.setDarkTheme(!this.dark);
      this.$vuetify.theme.dark = !this.dark; // firefox so funciona assim
    },
  },
  watch: {
    dark: {
      handler(v) {
        this.temaEscuro = v;
      },
      immediate: true,
    },
    usuario: {
      handler(v) {
        this.$vuetify.theme.dark = v == null ? false : v.opcoes.darkTheme; // tela de login não terá darkTheme
      },
      immediate: true,
    },
    isLotacaoFisica: {
      handler(v) {
        this.lotacaoFisica = v;
      },
      immediate: true,
    },
  },
};
</script>

<style scoped>
.name-bt {
  font-family: "Futura Light" !important;
}
.user-desc {
  background-color: #48586c;
  text-align: center;
}
.theme--dark .user-desc {
  background-color: #363636;
}
</style>
