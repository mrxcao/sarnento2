<template>
  <div class="d-flex">
    <div class="menubarra-border"></div>
    <template v-if="mostraBotoes">
      <template v-for="item in menuItems">
        <v-badge
          :id="'menuBotao' + item.id.toString()"
          :class="{ informeBadge2: badgeValue(item.id) }"

          content="Novo!"
          :value="badgeValue(item.id)"
          color="error"
          right
          overlap
        >
          <v-btn large text :to="item.to" class="menubarra-border">
            {{ item.texto }}
          </v-btn>
        </v-badge>
      </template>
    </template>
    <div class="mr-5 ml-5">
      <v-text-field
        ref="searchInput"
        class="expanding-search"
        prepend-inner-icon="mdi-magnify"
        v-model="searchInputValue"
        dense
        placeholder="Pesquisa Nro Atende"
        rounded
        filled
        hide-details
        :class="{ 'search-closed': searchClosed && !searchInputValue }"
        @focus="searchClosed = false"
        @blur="searchClosed = true"
        @keyup="removeNaoNumericos()"
        @keyup.enter="searchAtende()"
        @click:prepend-inner="expandeOuPesquisaAtende"
      ></v-text-field>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  props: {
    search: String,
    mostraBotoes: Boolean,
  },
  data() {
    return {
      menuItems: [
        {
          id: 1,
          texto: 'Novo atende',
          to: '/novo',
        },
        {
          id: 2,
          texto: 'Responder',
          to: '/home',
        },
        /* {
          id: 3,
          texto: "Dashboard",
          to: "/dashboard",
        }, */
        {
          id: 4,
          texto: 'Informe',
          to: '/alertas',
        },
      ],
      searchClosed: true,
      searchInputValue: '',
    };
  },
  computed: {
    ...mapGetters('alertas', ['novoAlertas']),
    /* searchInputValue: {
      get() {
        return this.search;
      },
      set(value) {
        this.$emit("update-search", value);
      },
    }, */
  },
  methods: {
    badgeValue(id) {
      if (id != 4) return 0;
      return this.novoAlertas;
    },
    searchAtende() {
      this.$router.push({
        name: 'Solicitacao',
        params: { id: this.searchInputValue },
      });
    },
    removeNaoNumericos() {
      this.searchInputValue = this.searchInputValue
        ? this.searchInputValue.replace(/[^0-9]/g, '')
        : this.searchInputValue;
    },
    expandeOuPesquisaAtende() {
      if (this.searchClosed) {
        this.searchClosed = false;
        this.$refs.searchInput.focus();
        return;
      }
      this.searchAtende();
    },
  },
};
</script>

<style scoped>
.menubarra-border {
  border-right: 1px solid #eee;
  border-radius: 0px !important;
  font-family: "Futura Light"!important;
}
.v-input.expanding-search {
  transition: all 0.2s;
}
.expanding-search >>> .v-input__prepend-inner {
  padding-right: 10px !important;
}
.v-input.expanding-search >>> .v-input__slot::after,
.v-input.expanding-search >>> .v-input__slot::before {
  border-color: transparent !important;
}
.search-closed {
  max-width: 40px !important;
}
.search-closed >>> .v-input__slot {
  background: transparent !important;
}
.search-closed >>> .v-input__icon {
  cursor: pointer;
}
</style>
<style>
#menuBotao4 .v-badge__badge{
  bottom: calc(100% - 22px) !important;
  left: calc(100% - 22px) !important;
}
</style>
