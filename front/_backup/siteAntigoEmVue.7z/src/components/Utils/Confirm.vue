<template>
  <v-dialog
    v-model="dialog"
    persistent
    scrollable
    :max-width="options.width ? options.width : 450"
    @keydown.enter="agree()"
    @keydown.esc="cancel()"
  >
    <v-card tile class="elevation-2">
      <v-card-text v-show="!!message || !!title" class="px-0 pt-0 pb-4">
        <v-row no-gutters>
          <v-col cols="12" align="center" justify="center" class="pt-10">
            <v-icon
              :color="options.color ? options.color : '#F9765E'"
              style="font-size: 100px"
            >
              {{ options.icon || "fas fa-exclamation-triangle" }}
            </v-icon>
          </v-col>
          <v-col
            cols="12"
            class="pt-6 confirm-text"
            align="center"
            justify="center"
          >
            {{ title }}
          </v-col>
          <v-col cols="12" class="pt-8 px-10 confirm-text" justify="center">
            <div v-html="message"></div>
          </v-col>
          <v-form ref="form-confirm" v-model="valid" v-if="hasCamposAdicionais">
            <v-row no-gutters class="py-0" justify="center">
              <v-col
                cols="12"
                class="px-10 confirm-text"
                v-for="campo in options.camposAdicionais.campos"
                v-bind:key="campo.id"
              >
                <v-text-field
                  v-if="campo.tipo === 'text' || campo.tipo === 'number'"
                  :counter="campo.contador"
                  :id="campo.id"
                  filled
                  :label="campo.texto"
                  outlined
                  :rules="campo.regras"
                  type="text"
                  v-model="campo.valor"
                  v-mask="campo.mascara"
                  class="py-0"
                >
                </v-text-field>
                <v-textarea
                  v-if="campo.tipo === 'textarea'"
                  :counter="campo.contador"
                  :id="campo.id"
                  filled
                  :label="campo.texto"
                  outlined
                  rows="4"
                  :rules="campo.regras"
                  v-model="campo.valor"
                ></v-textarea>
              </v-col>
            </v-row>
          </v-form>
        </v-row>
      </v-card-text>
      <v-card-actions class="pt-8 px-15 pb-10 justify-center">
        <v-btn
          class="pr-10 pl-10 mr-16"
          color="primary"
          outlined
          v-if="!options.okOnly"
          @click.native="cancel()"
          style="font-size: 14px"
        >
          {{ defineTextoCancelar }}
        </v-btn>
        <v-btn
          class="white--text primary pr-10 pl-10"
          color="primary"
          @click.native="agree()"
          style="font-size: 14px"
          :disabled="!isFormValido()"
        >
          {{ defineTextoConfirm }}
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import TextoUtils from "../../utils/TextoUtils";

/**
 * Vuetify Confirm Dialog component
 *
 * Uso:
 * this.$root.$confirm(titulo, mensagem, opções).then(confirm => {})
 *
 * exmp:
 * this.$root.$confirm.open('Apagar', 'certeza?', { color: 'red' }).then((confirm) => {});
 *
 */
export default {
  data() {
    return {
      dialog: false,
      resolve: null,
      reject: null,
      message: null,
      textoConfirmar: null,
      textoCancelar: null,
      title: null,
      options: {
        okOnly: false,
        camposAdicionais: {
          quantidade: 0,
          campos: [
            {
              id: null,
              nome: "",
              tipo: "",
              valor: null,
              mascara: "",
              regras: [],
              contador: 0,
            },
          ],
        },
      },
      valid: false,
    };
  },
  methods: {
    open(title, message, options) {
      this.dialog = true;
      this.title = title;
      this.message = message;
      this.options = Object.assign(this.options, options);

      if (this.options.textoConfirmar)
        this.textoConfirmar = this.options.textoConfirmar;
      else {
        this.textoConfirmar = null;
      }
      if (this.options.textoCancelar)
        this.textoCancelar = this.options.textoCancelar;
      else {
        this.textoCancelar = null;
      }

      return new Promise((resolve, reject) => {
        this.resolve = resolve;
        this.reject = reject;
      });
    },
    limparFechar() {
      this.dialog = false;
      this.title = "";
      this.message = "";
      this.options = {
        okOnly: false,
        camposAdicionais: [],
      };
    },
    agree() {
      if (this.hasCamposAdicionais) {
        this.resolve(this.construirResposta());
      } else {
        this.resolve(true);
      }
      this.limparFechar();
    },
    cancel() {
      if (!this.options.okOnly) {
        this.resolve(false);
        this.limparFechar();
      }
    },
    isFormValido() {
      if (!this.options.camposAdicionais.quantidade) {
        return true;
      }
      return this.valid;
    },
    construirResposta() {
      const resposta = {};
      this.options.camposAdicionais.campos.forEach((campo) => {
        if (campo.nome && campo.nome.length > 0) {
          campo.tipo === "number"
            ? (resposta[campo.nome] = TextoUtils.converterStringParaNumber(
                campo.valor
              ))
            : (resposta[campo.nome] = campo.valor);
        }
      });

      return resposta;
    },
  },
  computed: {
    defineTextoConfirm() {
      let retorno = "";
      if (!this.textoConfirmar)
        retorno = this.options.okOnly ? "Ok" : "Confirmar";
      else retorno = this.textoConfirmar;

      return retorno;
    },
    defineTextoCancelar() {
      let retorno = !this.textoCancelar ? "Cancelar" : this.textoCancelar;

      return retorno;
    },
    hasCamposAdicionais() {
      return this.options.camposAdicionais.quantidade > 0;
    },
  },
};
</script>

<style scoped>
.confirm-text {
  font-family: "Futura Light", sans-serif;
  font-weight: 300;
  font-size: 14px;
  line-height: 20px;
  color: #333;
  text-align: center;
}
.theme--dark .confirm-text {
  color: #fff !important;
}
</style>
