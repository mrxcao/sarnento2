<template>
  <v-overlay :value="show" :z-index="999" :opacity="0.8">
    <div class="div-block-11">
      <div class="div-block-12">
        <div>
          <div class="dot-flashing"></div>
        </div>
      </div>
    </div>
  </v-overlay>
</template>

<script>
import { mapState } from "vuex";
export default {
  computed: {
    ...mapState("loading", { show: "active" }),
  },
};
</script>

<style scoped>
.div-block-11 {
  width: 102px;
  height: 84px;
  background-image: url(~@/assets/img/logo_atende.png);
  background-position: 0px 0px;
  background-size: auto;
}
.div-block-12 {
  margin-top: 0px;
  margin-left: 0px;
  padding-top: 30px;
  padding-bottom: 20px;
  padding-left: 0px;
}
.dot-flashing {
  margin-left: 40px;
  position: relative;
  width: 5px;
  height: 5px;
  border-radius: 5px;
  background-color: #b6b6b6;
  color: #b6b6b6;
  animation: dotFlashing 0.8s infinite linear alternate;
  animation-delay: 0.3s;
}
.dot-flashing::before,
.dot-flashing::after {
  content: "";
  display: inline-block;
  position: absolute;
  top: 0;
}
.dot-flashing::before {
  left: -10px;
  width: 5px;
  height: 5px;
  border-radius: 5px;
  background-color: #b6b6b6;
  color: #b6b6b6;
  animation: dotFlashing 0.8s infinite alternate;
  animation-delay: 0s;
}
.dot-flashing::after {
  left: 10px;
  width: 5px;
  height: 5px;
  border-radius: 5px;
  background-color: #b6b6b6;
  color: #b6b6b6;
  animation: dotFlashing 0.8s infinite alternate;
  animation-delay: 0.6s;
}
@keyframes dotFlashing {
  0% {
    background-color: #005CA9;
  }
  50%,
  100% {
    background-color: #fff;
  }
}
</style>