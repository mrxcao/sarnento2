<template>
  <v-snackbar
    v-model="show"
    :color="color"
    :left="position.includes('left')"
    :right="position.includes('right')"
    :top="position.includes('top')"
    :bottom="position.includes('bottom')"
    :centered="position.includes('center')"
    :timeout="timeout"
  >
    {{ text }}
    <template v-slot:action="{ attrs }">
      <v-btn icon v-bind="attrs" @click="show = false">
        <v-icon>mdi-close</v-icon>
      </v-btn>
    </template>
  </v-snackbar>
</template>

<script>
export default {
  data() {
    return {
      show: false,
      text: "",
      color: "",
      position: "",
      multiline: false,
      timeout: 5000,
    };
  },
  created() {
    this.$store.subscribe((mutation, state) => {
      if (mutation.type === "snackbar/SET_ACTIVE") {
        this.text = state.snackbar.text;
        this.color = state.snackbar.color;
        this.position = state.snackbar.position;
        this.timeout = state.snackbar.timeout;
        this.multiline = state.snackbar.multiline;
        this.show = true;
      }
    });
  },
};
</script>